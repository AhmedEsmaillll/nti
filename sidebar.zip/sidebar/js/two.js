const links = document.querySelectorAll(".social-sidebar a");

links.forEach(link => {
  link.addEventListener("click", (e) => {
    e.preventDefault();

    // شيل active من كل العناصر
    links.forEach(l => l.classList.remove("active"));

    // ضيف active على اللي اتضغط عليه
    link.classList.add("active");
  });
});
