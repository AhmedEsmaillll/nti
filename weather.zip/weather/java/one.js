    const apiKey = "7291c6c40dc2fba0eade9193a7a6075b"; // مفتاحك

    async function getWeather() {
      const city = document.getElementById("cityInput").value;
      if (!city) return alert("Please enter a city");

      localStorage.setItem("lastCity", city);

      const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=en`;

      try {
        const response = await fetch(url);
        const data = await response.json();

        if (data.cod === "404") {
          alert("City not found");
          return;
        }

        document.getElementById("cityName").textContent = data.name;
        document.getElementById("temp").textContent = `${data.main.temp}°C`;
        document.getElementById("condition").textContent = data.weather[0].description;

        // اختيار الأيقونة حسب حالة الطقس
        const condition = data.weather[0].main.toLowerCase();
        const icon = document.getElementById("icon");

        if (condition.includes("cloud")) icon.textContent = "☁️";
        else if (condition.includes("rain")) icon.textContent = "🌧️";
        else if (condition.includes("clear")) icon.textContent = "☀️";
        else if (condition.includes("snow")) icon.textContent = "❄️";
        else if (condition.includes("storm")) icon.textContent = "⛈️";
        else icon.textContent = "🌍";

      } catch (err) {
        alert("Error fetching weather data");
      }
    }

    // تحميل آخر مدينة عند فتح الصفحة
    window.onload = () => {
      const lastCity = localStorage.getItem("lastCity");
      if (lastCity) {
        document.getElementById("cityInput").value = lastCity;
        getWeather();
      }
    };
